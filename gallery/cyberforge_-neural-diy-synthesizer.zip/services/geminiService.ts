
import { GoogleGenAI, Type } from "@google/genai";
import { MachineDesign, Part, MachineConfig, BOMItem } from "../types";

const cleanJsonResponse = (text: string) => {
  return text.replace(/```json/g, "").replace(/```/g, "").trim();
};

export const generateDesigns = async (parts: Part[], config: MachineConfig): Promise<MachineDesign[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const difficultyReq = {
    'Easy': "Simple 3-5 part assembly. Direct logic.",
    'Moderate': "Balanced 5-10 part circuit. Functional prototype.",
    'Hard': "Advanced 10-15 part system. High complexity, tight integration."
  }[config.difficulty];

  const powerPrompt = config.useBattery 
    ? `Power: Integrated ${config.powerType} battery system.` 
    : "Power: External USBC link.";

  const visualStyle = `Material: ${config.structureMaterial}. ${config.brassWires ? 'Uses point-to-point exposed Brass Wiring.' : ''} ${config.brassLight ? 'Features warm Brass Light fixtures.' : ''}`;

  const partConstraint = parts.length > 0 
    ? `MUST USE THESE NODES: [${parts.map(p => p.name).join(', ')}]. You can add additional suitable passives/hardware.`
    : `NO SPECIFIC NODES PROVIDED. You must brainstorm and define the entire Bill of Materials (BOM) based on the research goal.`;

  const prompt = `
    CONTEXT: CyberForge Neural Workshop.
    RESEARCH GOAL: "${config.userPrompt}"
    ${partConstraint}
    SETTINGS: Difficulty: ${config.difficulty} (${difficultyReq}). ${visualStyle}
    ${powerPrompt}

    TASK: Generate EXACTLY THREE (3) unique, distinct, and creative MachineDesign JSON objects. 
    Vary the names and descriptions across the triad.
    Each design should be a functional-looking hardware interpretation of the goal "${config.userPrompt}".
    Ensure the BOM includes parts appropriate for the style "${config.structureMaterial}".
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            name: { type: Type.STRING },
            purpose: { type: Type.STRING },
            synergy: { type: Type.STRING },
            type: { type: Type.STRING },
            description: { type: Type.STRING },
            bom: { 
              type: Type.ARRAY, 
              items: { 
                type: Type.OBJECT,
                properties: {
                  part: { type: Type.STRING },
                  quantity: { type: Type.STRING },
                  purpose: { type: Type.STRING }
                },
                required: ["part", "quantity", "purpose"]
              } 
            }
          },
          required: ["id", "name", "purpose", "synergy", "type", "description", "bom"]
        }
      }
    }
  });

  const text = response.text || "[]";
  const parsed = JSON.parse(cleanJsonResponse(text));
  // Ensure we have exactly 3
  return parsed.slice(0, 3).map((d: any) => ({ ...d, images: [] }));
};

export const generateImageForDesign = async (
  design: MachineDesign, 
  config: MachineConfig
): Promise<string | undefined> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const materialAesthetic = config.structureMaterial === '3D Print' 
    ? "Exposed 3D printed chassis with structural lattice." 
    : `${config.structureMaterial} industrial hardware.`;

  const accents = `${config.brassWires ? 'EXPOSED POINT-TO-POINT BRASS WIRING.' : ''} ${config.brassLight ? 'WARM BRASS FILAMENT LIGHT HOUSINGS.' : ''}`;

  const prompt = `
    MASTERPIECE INDUSTRIAL PRODUCT PHOTOGRAPHY. 
    Machine: "${design.name}". 
    Style: ${materialAesthetic}
    ${accents}
    Visual Logic: Components (${design.bom.slice(0, 5).map(b => b.part).join(', ')}) integrated into the chassis. 
    STRICTLY NO TEXT LABELS, NO WATERMARKS. 
    Industrial top-down flatlay, cinematic lighting, high contrast, 1:1 Aspect.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: [{ text: prompt }] },
      config: { imageConfig: { aspectRatio: "1:1" } }
    });
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
  } catch (err) {
    console.error("Image generation failed:", err);
  }
  return undefined;
};

export const generatePartDocumentation = async (partName: string): Promise<string | undefined> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `Detailed technical line art blueprint of ${partName} on a dark grid background.`;
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: [{ text: prompt }] },
      config: { imageConfig: { aspectRatio: "4:3" } }
    });
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
  } catch (err) {}
  return undefined;
};

export const generateRealPartAbstract = async (partName: string): Promise<{ abstract: string, specs: string[] } | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Provide a real technical summary and 4 key specs for the component: ${partName}.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            abstract: { type: Type.STRING },
            specs: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["abstract", "specs"]
        }
      }
    });
    const text = response.text;
    if (text) return JSON.parse(cleanJsonResponse(text));
  } catch (e) {}
  return null;
};
