
import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { Part, MachineDesign, AppStatus, MachineConfig, StructureMaterial, BOMItem, Difficulty, BatteryType } from './types';
import PartSelector from './components/PartSelector';
import PartDetailPopup from './components/PartDetailPopup';
import SynthesisProgress from './components/SynthesisProgress';
import { generateDesigns, generateImageForDesign } from './services/geminiService';
import { COMMON_PARTS } from './constants';

const VERSION = "v13.1.0-METADATA-STAMP";
const DROPBOX_URL = "https://www.dropbox.com/scl/fo/ycjjc58urymda364zmish/AHM7PSy3hgVZjZSKukaXVDs?rlkey=fu4g8s6eoafb4h5m9p329wj3m&st=i3wncjhv&dl=0";

/**
 * Transcodes a base64 image and STAMPS metadata (Name, Desc, BOM) onto the canvas.
 */
const convertToWebPBlobWithMetadata = (base64: string, design: MachineDesign): Promise<Blob> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const padding = 60;
      const footerHeight = 450; // Extra space for technical specs
      const canvas = document.createElement('canvas');
      
      canvas.width = img.width;
      canvas.height = img.height + footerHeight;
      
      const ctx = canvas.getContext('2d');
      if (!ctx) return reject(new Error("Canvas context error"));

      // 1. Draw Background
      ctx.fillStyle = '#050505';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // 2. Draw Original Artwork
      ctx.drawImage(img, 0, 0);

      // 3. Render Technical Passport Overlay
      const drawY = img.height + padding;
      
      // Accent Line
      ctx.strokeStyle = '#00f3ff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(padding, drawY - 20);
      ctx.lineTo(canvas.width - padding, drawY - 20);
      ctx.stroke();

      // Title
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 42px "Orbitron", sans-serif';
      ctx.fillText(design.name.toUpperCase(), padding, drawY + 40);

      // Description
      ctx.fillStyle = '#888888';
      ctx.font = 'italic 18px "JetBrains Mono", monospace';
      const descWords = design.description.split(' ');
      let line = '';
      let descY = drawY + 80;
      for (let n = 0; n < descWords.length; n++) {
        const testLine = line + descWords[n] + ' ';
        const metrics = ctx.measureText(testLine);
        if (metrics.width > (canvas.width - padding * 2) && n > 0) {
          ctx.fillText(line, padding, descY);
          line = descWords[n] + ' ';
          descY += 25;
        } else {
          line = testLine;
        }
      }
      ctx.fillText(line, padding, descY);

      // BOM Header
      ctx.fillStyle = '#ff00ff';
      ctx.font = 'bold 16px "JetBrains Mono", monospace';
      ctx.fillText('BILL OF MATERIALS MANIFEST', padding, descY + 60);

      // BOM Content
      ctx.fillStyle = '#00f3ff';
      ctx.font = '14px "JetBrains Mono", monospace';
      let bomY = descY + 90;
      design.bom.forEach((item, idx) => {
        if (bomY < canvas.height - 40) {
          const text = `[${item.quantity}] ${item.part.padEnd(30, '.')} ${item.purpose}`;
          ctx.fillText(text.toUpperCase(), padding, bomY);
          bomY += 22;
        }
      });

      // Footer Branding
      ctx.fillStyle = '#222222';
      ctx.font = 'bold 12px "JetBrains Mono", monospace';
      ctx.textAlign = 'right';
      ctx.fillText(`CYBERFORGE_SYNTHESIZER_${VERSION}`, canvas.width - padding, canvas.height - padding/2);
      ctx.textAlign = 'left';
      ctx.fillText(`ID: ${design.id}`, padding, canvas.height - padding/2);

      canvas.toBlob((blob) => {
        if (blob) resolve(blob);
        else reject(new Error("WebP Transcoding Failed"));
      }, 'image/webp', 0.95);
    };
    img.onerror = () => reject(new Error("Image loading error"));
    img.src = base64;
  });
};

/**
 * Standard browser download
 */
const downloadFile = (blob: Blob, fileName: string) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

const CategoryPictogram: React.FC<{ category: string, className?: string }> = ({ category, className = "w-6 h-6" }) => {
  const c = category.toLowerCase();
  if (c.includes('core') || c.includes('mcu')) {
    return (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className}>
        <rect x="6" y="6" width="12" height="12" rx="1" />
        <path d="M9 6V3M12 6V3M15 6V3M9 18v3M12 18v3M15 18v3M6 9H3M6 12H3M6 15H3M18 9h3M18 12h3M18 15h3" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className={className}>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v10M7 12h10" />
    </svg>
  );
};

const BOMRow: React.FC<{ item: BOMItem, onInspect: (n: string) => void }> = ({ item, onInspect }) => (
  <div 
    onClick={() => onInspect(item.part)}
    className="p-4 border-b border-white/5 flex items-center gap-4 hover:bg-white/5 transition-all cursor-pointer group"
  >
    <div className="w-10 h-10 flex items-center justify-center border border-white/5 bg-black shrink-0">
       <CategoryPictogram category={item.part} className="w-5 h-5 text-[#00f3ff]" />
    </div>
    <div className="flex-1 min-w-0">
      <div className="flex justify-between items-start">
        <h5 className="text-[10px] font-black uppercase truncate text-gray-300 group-hover:text-[#00f3ff] transition-colors">
          {item.part}
        </h5>
        <span className="text-[9px] text-[#00f3ff] font-mono font-bold">x{item.quantity}</span>
      </div>
      <p className="text-[8px] text-gray-600 italic mt-0.5 font-mono uppercase truncate">{item.purpose}</p>
    </div>
  </div>
);

const App: React.FC = () => {
  const [view, setView] = useState<'forge' | 'gallery'>('forge');
  const [availableParts, setAvailableParts] = useState<Part[]>(COMMON_PARTS);
  const [selectedParts, setSelectedParts] = useState<Part[]>([]);
  const [config, setConfig] = useState<MachineConfig>({ 
    useBattery: true, 
    powerType: '18650',
    structureMaterial: 'Brass',
    difficulty: 'Moderate',
    userPrompt: '',
    brassLight: true,
    brassWires: false
  });
  
  const [designs, setDesigns] = useState<MachineDesign[]>([]);
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [activeDesignIndex, setActiveDesignIndex] = useState(-1);
  const [isImageLoading, setIsImageLoading] = useState(false);
  const [inspectedPart, setInspectedPart] = useState<Part | null>(null);
  const [isDataReady, setIsDataReady] = useState(false);
  const [isSavingBatch, setIsSavingBatch] = useState(false);

  const saveDesignToLocal = async (design: MachineDesign, base64: string) => {
    try {
      const blob = await convertToWebPBlobWithMetadata(base64, design);
      const fileName = `cyberforge_${design.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${Date.now()}.webp`;
      downloadFile(blob, fileName);
      return true;
    } catch (e) {
      console.error(`Save Error [${design.name}]:`, e);
      return false;
    }
  };

  const handleManualBatchSave = async () => {
    const triad = designs.slice(-3);
    if (triad.length === 0) {
      alert("FORGE EMPTY: No designs in buffer.");
      return;
    }
    
    setIsSavingBatch(true);
    let success = 0;
    try {
      for (const design of triad) {
        if (design.images && design.images[0]) {
          const ok = await saveDesignToLocal(design, design.images[0]);
          if (ok) success++;
        }
      }
      if (success > 0) alert(`DATASHEETS GENERATED: ${success} full-spec blueprints downloaded.`);
    } catch (e) {
      console.error("Batch Save Error:", e);
    } finally {
      setIsSavingBatch(false);
    }
  };

  const handleSynthesize = async () => {
    if (selectedParts.length === 0 && config.userPrompt.trim().length === 0) {
      alert("WORKBENCH VACANT: Add parts OR describe your artifact in the NEURAL_PROMPT to begin.");
      return;
    }

    setStatus(AppStatus.GENERATING);
    setIsDataReady(false);
    try {
      const triad = await generateDesigns(selectedParts, config);
      if (triad && triad.length > 0) {
        setDesigns(prev => [...prev, ...triad]);
        setIsDataReady(true);
      }
    } catch (err: any) {
      console.error("Synthesis Core Error:", err);
      setStatus(AppStatus.ERROR);
      alert("NEURAL_LINK_ERROR: Synthesis interrupted.");
    }
  };

  // Image generation
  useEffect(() => {
    const pending = designs.filter(d => d.images.length === 0);
    if (pending.length > 0 && status === AppStatus.SUCCESS && !isImageLoading) {
      (async () => {
        setIsImageLoading(true);
        try {
          const results = await Promise.all(pending.map(async (design) => {
            const img = await generateImageForDesign(design, config);
            return { id: design.id, img };
          }));

          setDesigns(prev => prev.map(d => {
            const match = results.find(r => r.id === d.id);
            if (match && match.img) return { ...d, images: [match.img] };
            return d;
          }));

          const lastIdx = designs.length - 1;
          const firstNewIdx = designs.findIndex(d => d.id === pending[0].id);
          setActiveDesignIndex(firstNewIdx >= 0 ? firstNewIdx : lastIdx);

        } catch (e) {
          console.error("Batch Rendering Error:", e);
        } finally {
          setIsImageLoading(false);
        }
      })();
    }
  }, [designs, status, config]);

  const activeDesign = activeDesignIndex >= 0 ? designs[activeDesignIndex] : null;

  return (
    <div className="min-h-screen bg-[#050505] text-gray-300 flex flex-col overflow-x-hidden selection:bg-[#00f3ff] selection:text-black">
      
      <header className="p-8 pb-4 bg-[#0a0a0f] flex items-center justify-between no-print border-b border-[#00f3ff11] z-50">
        <div className="flex items-center gap-6">
          <h1 className="cyber-font text-4xl font-black text-white glitch-text italic tracking-tighter leading-none">CYBERFORGE</h1>
          <div className="flex flex-col">
            <span className="text-[10px] font-mono text-[#00f3ff] bg-[#00f3ff11] px-2 py-0.5 border border-[#00f3ff22]">{VERSION}</span>
          </div>
        </div>
        
        <div className="flex items-center gap-2 bg-black border border-gray-900 p-1 rounded-sm">
           <button onClick={() => setView('forge')} className={`px-6 py-2 text-[11px] font-black uppercase transition-all ${view === 'forge' ? 'bg-[#00f3ff] text-black shadow-[0_0_15px_rgba(0,243,255,0.3)]' : 'text-gray-600 hover:text-white'}`}>FORGE</button>
           <button onClick={() => setView('gallery')} className={`px-6 py-2 text-[11px] font-black uppercase transition-all ${view === 'gallery' ? 'bg-[#ff00ff] text-white shadow-[0_0_15px_rgba(255,0,255,0.3)]' : 'text-gray-600 hover:text-white'}`}>GALLERY ({designs.length})</button>
        </div>

        <div className="flex gap-4">
           <button onClick={() => { setDesigns([]); setStatus(AppStatus.IDLE); setActiveDesignIndex(-1); }} className="px-6 py-2 text-[11px] font-black border border-gray-800 text-gray-500 hover:text-white transition-all uppercase bg-black/50">PURGE_SESSION</button>
        </div>
      </header>

      <main className="w-full mx-auto p-8 pt-6 space-y-8 flex flex-col relative flex-1">
        {view === 'forge' ? (
          <>
            <section className={`space-y-6 transition-opacity duration-500 ${status === AppStatus.GENERATING ? 'opacity-30 pointer-events-none' : 'opacity-100'}`}>
               <div className="space-y-4">
                  <div className="text-[11px] text-[#00f3ff] font-black uppercase tracking-[0.4em] italic flex items-center justify-between">
                    <span>NEURAL_PROMPT</span>
                    {selectedParts.length === 0 && config.userPrompt.trim().length > 0 && (
                      <span className="text-[#ff00ff] animate-pulse text-[8px] border border-[#ff00ff44] px-2 py-0.5">NEURAL_DREAM_MODE: ACTIVE</span>
                    )}
                  </div>
                  <textarea 
                    value={config.userPrompt}
                    onChange={(e) => setConfig(prev => ({ ...prev, userPrompt: e.target.value }))}
                    placeholder="Enter parameters... e.g. 'tiny house from plywood with oled screen'"
                    className="w-full h-24 bg-[#0a0a0f] border border-gray-900 p-6 text-base text-white focus:outline-none focus:border-[#00f3ff] font-mono transition-all resize-none shadow-inner"
                  />
               </div>

               <div className="flex flex-wrap gap-8 items-start py-6 border-t border-white/5 bg-[#0a0a0f]/30 p-6 rounded-sm">
                  <div className="space-y-3">
                    <div className="text-[9px] text-gray-600 font-black uppercase tracking-widest">Complexity</div>
                    <div className="flex bg-black border border-gray-900 p-0.5">
                      {(['Easy', 'Moderate', 'Hard'] as Difficulty[]).map(d => (
                        <button key={d} onClick={() => setConfig(prev => ({ ...prev, difficulty: d }))} className={`px-4 py-2 text-[10px] font-black uppercase transition-all ${config.difficulty === d ? 'bg-white text-black' : 'text-gray-600 hover:text-white'}`}>{d}</button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="text-[9px] text-gray-600 font-black uppercase tracking-widest">Frame_Material</div>
                    <div className="flex bg-black border border-gray-900 p-0.5">
                      {(['Brass', 'Acrylic', 'Plywood', '3D Print'] as StructureMaterial[]).map(mat => (
                        <button key={mat} onClick={() => setConfig(prev => ({ ...prev, structureMaterial: mat }))} className={`px-4 py-2 text-[10px] font-black uppercase transition-all ${config.structureMaterial === mat ? 'bg-[#00f3ff] text-black shadow-[0_0_10px_#00f3ff33]' : 'text-gray-600 hover:text-white'}`}>{mat}</button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="text-[9px] text-gray-600 font-black uppercase tracking-widest">Aesthetic_Engine</div>
                    <div className="flex gap-4">
                       <button onClick={() => setConfig(prev => ({ ...prev, brassLight: !prev.brassLight }))} className={`px-4 py-2 text-[10px] font-black uppercase border transition-all ${config.brassLight ? 'border-[#ff00ff] text-[#ff00ff] bg-[#ff00ff05]' : 'border-gray-900 text-gray-700'}`}>BRASS_LUMENS: {config.brassLight ? 'ON' : 'OFF'}</button>
                       <button onClick={() => setConfig(prev => ({ ...prev, brassWires: !prev.brassWires }))} className={`px-4 py-2 text-[10px] font-black uppercase border transition-all ${config.brassWires ? 'border-[#00f3ff] text-[#00f3ff] bg-[#00f3ff05]' : 'border-gray-900 text-gray-700'}`}>POINT_WIRING: {config.brassWires ? 'ON' : 'OFF'}</button>
                    </div>
                  </div>
                  
                  <div className="ml-auto flex items-center justify-center pt-2">
                     <button 
                        onClick={handleSynthesize} 
                        className={`group relative px-12 py-5 border-2 flex items-center justify-center transition-all duration-300 ${selectedParts.length === 0 ? 'border-[#ff00ff] hover:bg-[#ff00ff] hover:shadow-[0_0_40px_rgba(255,0,255,0.4)]' : 'border-[#00f3ff] hover:bg-[#00f3ff] hover:shadow-[0_0_40px_rgba(0,243,255,0.4)]'}`}
                     >
                        <span className={`text-xl font-black cyber-font italic tracking-[0.2em] group-hover:text-black ${selectedParts.length === 0 ? 'text-[#ff00ff]' : 'text-[#00f3ff]'}`}>
                          {selectedParts.length === 0 ? 'RANDOM_FORGE' : 'FORGE_TRIAD'}
                        </span>
                     </button>
                  </div>
               </div>
            </section>

            <section className={`bg-black/40 border border-[#00f3ff11] transition-opacity duration-500 ${status === AppStatus.GENERATING ? 'opacity-30 pointer-events-none' : 'opacity-100'}`}>
              <PartSelector 
                availableParts={availableParts} 
                selectedParts={selectedParts} 
                onAddPart={(p) => setSelectedParts(prev => [...prev, p])} 
                onRegisterPart={(p) => setAvailableParts(prev => [...prev, p])} 
                onRemovePart={(id) => setSelectedParts(prev => prev.filter(p => p.id !== id))}
                onInspectPart={setInspectedPart}
              />
            </section>

            {status === AppStatus.GENERATING && (
              <SynthesisProgress isDataReady={isDataReady} onComplete={() => setStatus(AppStatus.SUCCESS)} />
            )}

            {activeDesign && (
              <main className="w-full animate-reveal space-y-12 pb-32 pt-12 border-t border-white/5">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
                   <div className="flex items-center gap-8">
                      <div className="text-[11px] text-gray-600 font-black uppercase tracking-[0.4em] italic">ARCHIVAL_VARIANTS:</div>
                      <div className="flex gap-4">
                         {designs.slice(-3).map((d, i) => {
                           const actualIndexInDesigns = designs.length - 3 + i;
                           return (
                             <button 
                               key={d.id} 
                               onClick={() => setActiveDesignIndex(actualIndexInDesigns)}
                               className={`w-20 h-20 border-2 transition-all overflow-hidden relative ${activeDesignIndex === actualIndexInDesigns ? 'border-[#00f3ff] scale-110 shadow-[0_0_20px_#00f3ff44]' : 'border-gray-900 opacity-40 hover:opacity-100'}`}
                             >
                                {d.images[0] ? <img src={d.images[0]} className="w-full h-full object-cover" /> : <div className="w-full h-full bg-black animate-pulse flex items-center justify-center text-[8px] text-gray-800">PROCESSING</div>}
                             </button>
                           );
                         })}
                      </div>
                   </div>

                   <button 
                    onClick={handleManualBatchSave}
                    disabled={isSavingBatch || isImageLoading || designs.length < 3}
                    className="px-12 py-5 bg-[#ff00ff] text-white text-[13px] font-black uppercase tracking-[0.3em] hover:bg-white hover:text-black transition-all flex items-center gap-5 shadow-[0_0_30px_rgba(255,0,255,0.25)]"
                   >
                     {isSavingBatch ? (
                       <span className="flex items-center gap-3"><span className="w-4 h-4 border-2 border-black border-t-transparent animate-spin rounded-full"></span> ARCHIVING...</span>
                     ) : (
                       <>
                         <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"></path></svg> 
                         EXPORT_BLUEPRINTS (WEBP)
                       </>
                     )}
                   </button>
                </div>

                <div className="flex flex-col lg:flex-row gap-12">
                   <div className="lg:w-2/3 flex flex-col gap-6">
                      <div className="aspect-square bg-[#050505] border border-white/10 relative overflow-hidden flex items-center justify-center shadow-2xl">
                         {isImageLoading && activeDesign.images.length === 0 ? (
                           <div className="flex flex-col items-center gap-6">
                              <div className="w-16 h-16 border-4 border-[#00f3ff11] border-t-[#00f3ff] rounded-full animate-spin"></div>
                              <div className="text-[#00f3ff] animate-pulse font-mono tracking-[0.6em] uppercase text-xs">visualizing_triad...</div>
                           </div>
                         ) : activeDesign.images && activeDesign.images[0] ? (
                           <img src={activeDesign.images[0]} className="w-full h-full object-cover transition-transform duration-700" />
                         ) : (
                           <div className="text-gray-900 uppercase font-mono text-[12px] tracking-[1em]">Neural Void</div>
                         )}
                         <div className="absolute bottom-6 right-6 bg-black/80 px-4 py-2 border border-[#ff00ff33] text-[9px] text-[#ff00ff] font-mono flex items-center gap-2 backdrop-blur-md">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#ff00ff] animate-ping"></span>
                            FULL_SPEC_EXPORT_READY
                         </div>
                      </div>
                      <div className="bg-[#0a0a0f]/50 p-10 border border-white/5 space-y-6">
                         <h2 className="text-6xl font-black text-white cyber-font italic uppercase leading-none tracking-tighter glitch-text">{activeDesign.name}</h2>
                         <p className="text-[16px] text-gray-400 leading-relaxed font-mono uppercase italic border-l-2 border-[#00f3ff33] pl-6 py-2">
                           "{activeDesign.description}"
                         </p>
                      </div>
                   </div>

                   <div className="lg:w-1/3 bg-[#0a0a0f] border border-white/5 flex flex-col shadow-2xl overflow-hidden min-h-[600px] relative">
                      <header className="p-10 text-[14px] text-[#00f3ff] font-black uppercase tracking-[0.6em] border-b border-white/5 bg-[#00f3ff05] flex justify-between items-center">
                         <span>BOM_MANIFEST</span>
                         <span className="text-gray-700 text-[10px] font-mono">NODES: {activeDesign.bom.length}</span>
                      </header>
                      <div className="flex-1 overflow-y-auto custom-scrollbar bg-black/20">
                         {activeDesign.bom.map((item, i) => (
                           <BOMRow key={i} item={item} onInspect={(n) => {
                              const existing = availableParts.find(p => p.name.toLowerCase() === n.toLowerCase());
                              setInspectedPart(existing || { id: 'v-' + Math.random(), name: n, category: 'Passive' });
                           }} />
                         ))}
                      </div>
                   </div>
                </div>
              </main>
            )}
          </>
        ) : (
          <section className="animate-reveal space-y-12">
             <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 border-b border-[#ff00ff33] pb-12">
                <div className="space-y-6">
                   <h2 className="text-7xl font-black text-white cyber-font italic uppercase leading-none tracking-tighter">ARCHIVE</h2>
                   <div className="flex flex-col gap-3 font-mono text-[11px] text-gray-500 uppercase tracking-[0.2em]">
                      <div className="flex items-center gap-5 text-[#ff00ff]">
                         <span>REMOTE_INDEX</span>
                         <span className="h-4 w-px bg-gray-800"></span>
                         <a href={DROPBOX_URL} target="_blank" className="hover:underline text-white font-black flex items-center gap-2">OPEN_DROPBOX <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg></a>
                      </div>
                   </div>
                </div>
             </div>
             
             <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-8 pb-40">
                {designs.slice().reverse().map((d, idx) => (
                   <div key={`sess-${d.id}`} className="group relative bg-[#0a0a0f] border border-white/5 p-3 hover:border-[#00f3ff] transition-all cursor-pointer flex flex-col" onClick={() => { setActiveDesignIndex(designs.indexOf(d)); setView('forge'); }}>
                      <div className="aspect-square bg-black overflow-hidden relative shadow-inner">
                         {d.images[0] ? <img src={d.images[0]} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" /> : <div className="w-full h-full flex items-center justify-center text-[10px] text-gray-800 animate-pulse uppercase font-mono">Decoding</div>}
                      </div>
                      <div className="mt-4 text-[11px] font-black uppercase truncate text-gray-400 group-hover:text-[#00f3ff] transition-colors">{d.name}</div>
                   </div>
                ))}
                {designs.length === 0 && (
                  <div className="col-span-full py-20 text-center border border-dashed border-gray-900">
                    <div className="text-gray-700 font-mono text-[10px] uppercase tracking-[1em]">Gallery_Empty</div>
                  </div>
                )}
             </div>
          </section>
        )}
      </main>

      <footer className="h-16 bg-[#0a0a0f] border-t border-[#00f3ff11] flex items-center justify-between px-10 text-[11px] text-gray-700 font-mono shrink-0 no-print">
         <div className="flex gap-12 uppercase tracking-widest">
            <span className="flex items-center gap-4 text-gray-500">
               NEURAL_LINK: STABLE
            </span>
         </div>
         <div className="opacity-40 italic tracking-[0.5em] text-[10px] hidden md:block uppercase font-black">
           MODE: DATASHEET_STAMPING // BATCH: 03_VARIANTS
         </div>
      </footer>

      {inspectedPart && <PartDetailPopup part={inspectedPart} onClose={() => setInspectedPart(null)} />}
    </div>
  );
};

export default App;
